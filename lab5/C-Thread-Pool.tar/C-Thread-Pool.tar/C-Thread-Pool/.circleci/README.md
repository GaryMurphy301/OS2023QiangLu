Build and push container

    docker build -t pithikos/test-c-thread-pool .
    docker push pithikos/test-c-thread-pool
